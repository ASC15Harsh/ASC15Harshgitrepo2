package com.demo.springbootIntergration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootIntergrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootIntergrationApplication.class, args);
	}

}
